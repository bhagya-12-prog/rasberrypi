from machine import Pin
import utime

led1 = Pin(12,Pin.OUT)
led2 = Pin(13,Pin.OUT)
while True:
  led1.toggle()
  led2.toggle()
  utime.sleep(0.5)